export interface Symptom {
  id: string;
  name: string;
  category: SymptomCategory;
  description: string;
  commonCauses: string[];
}

export interface UserSymptom {
  symptom: Symptom;
  severity: SeverityLevel;
  duration: string;
  notes?: string;
}

export interface Analysis {
  conditions: PossibleCondition[];
  recommendations: Recommendation[];
  urgencyLevel: UrgencyLevel;
  confidence: number;
}

export interface PossibleCondition {
  name: string;
  probability: number;
  description: string;
  commonSymptoms: string[];
  recommendedAction: string;
}

export interface Recommendation {
  type: RecommendationType;
  message: string;
  priority: number;
}

export type SymptomCategory = 
  | 'general'
  | 'respiratory'
  | 'digestive'
  | 'neurological'
  | 'cardiovascular'
  | 'musculoskeletal'
  | 'skin'
  | 'mental-health';

export type SeverityLevel = 'mild' | 'moderate' | 'severe';

export type UrgencyLevel = 'low' | 'moderate' | 'high' | 'emergency';

export type RecommendationType = 
  | 'see-doctor'
  | 'emergency'
  | 'self-care'
  | 'monitor'
  | 'lifestyle';