import React from 'react';
import { Loader2, Brain, Search, CheckCircle2 } from 'lucide-react';

export const LoadingAnalysis: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
        <div className="relative mb-6">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <Brain className="h-12 w-12 text-blue-500" />
              <Loader2 className="h-6 w-6 text-blue-500 animate-spin absolute -top-1 -right-1" />
            </div>
          </div>
          
          <h2 className="text-xl font-bold text-gray-900 mb-2">Analyzing Your Symptoms</h2>
          <p className="text-gray-600 text-sm">Our AI is processing your information to provide the best possible assessment</p>
        </div>

        <div className="space-y-3 text-left">
          <div className="flex items-center gap-3 p-2 bg-blue-50 rounded">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            <span className="text-sm text-gray-700">Processing symptoms...</span>
          </div>
          
          <div className="flex items-center gap-3 p-2 bg-gray-50 rounded">
            <Search className="h-4 w-4 text-blue-500 animate-pulse" />
            <span className="text-sm text-gray-700">Matching with medical database...</span>
          </div>
          
          <div className="flex items-center gap-3 p-2 bg-gray-50 rounded">
            <Brain className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-500">Generating recommendations...</span>
          </div>
        </div>

        <div className="mt-6 text-xs text-gray-500">
          This usually takes 1-3 seconds
        </div>
      </div>
    </div>
  );
};