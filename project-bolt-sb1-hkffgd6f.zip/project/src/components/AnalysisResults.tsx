import React from 'react';
import { AlertTriangle, CheckCircle, Clock, Heart, User, Phone } from 'lucide-react';
import { Analysis, UrgencyLevel } from '../types/medical';

interface AnalysisResultsProps {
  analysis: Analysis;
  onNewAnalysis: () => void;
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({
  analysis,
  onNewAnalysis
}) => {
  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'emergency': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'moderate': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getUrgencyIcon = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'emergency': return <Phone className="h-5 w-5" />;
      case 'high': return <AlertTriangle className="h-5 w-5" />;
      case 'moderate': return <Clock className="h-5 w-5" />;
      case 'low': return <CheckCircle className="h-5 w-5" />;
      default: return <Clock className="h-5 w-5" />;
    }
  };

  const getUrgencyMessage = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'emergency': return 'Requires immediate medical attention';
      case 'high': return 'Should see a doctor soon';
      case 'moderate': return 'Monitor and consider medical consultation';
      case 'low': return 'Generally manageable with self-care';
      default: return 'Assessment complete';
    }
  };

  return (
    <div className="space-y-6">
      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-red-800 mb-1">Important Medical Disclaimer</h3>
            <p className="text-sm text-red-700">
              This tool provides general information only and is not a substitute for professional medical advice, 
              diagnosis, or treatment. Always consult with qualified healthcare providers for medical concerns.
            </p>
          </div>
        </div>
      </div>

      {/* Urgency Level */}
      <div className={`border rounded-lg p-4 ${getUrgencyColor(analysis.urgencyLevel)}`}>
        <div className="flex items-center gap-3 mb-2">
          {getUrgencyIcon(analysis.urgencyLevel)}
          <h2 className="text-xl font-bold">Assessment Result</h2>
        </div>
        <p className="font-medium">{getUrgencyMessage(analysis.urgencyLevel)}</p>
        <p className="text-sm mt-1">Confidence Level: {Math.round(analysis.confidence * 100)}%</p>
      </div>

      {/* Possible Conditions */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Possible Conditions</h2>
        <div className="space-y-4">
          {analysis.conditions.map((condition, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-gray-900">{condition.name}</h3>
                <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {Math.round(condition.probability * 100)}% match
                </span>
              </div>
              <p className="text-gray-700 mb-3">{condition.description}</p>
              
              <div className="mb-3">
                <h4 className="font-medium text-gray-800 mb-1">Common symptoms for this condition:</h4>
                <div className="flex flex-wrap gap-1">
                  {condition.commonSymptoms.map((symptom, i) => (
                    <span key={i} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                      {symptom}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 rounded p-3">
                <h4 className="font-medium text-blue-900 mb-1">Recommended Action:</h4>
                <p className="text-blue-800 text-sm">{condition.recommendedAction}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recommendations</h2>
        <div className="space-y-3">
          {analysis.recommendations
            .sort((a, b) => a.priority - b.priority)
            .map((recommendation, index) => (
              <div key={index} className="flex items-start gap-3 p-3 border border-gray-200 rounded-lg">
                <div className="flex-shrink-0 mt-0.5">
                  {recommendation.type === 'emergency' && <Phone className="h-4 w-4 text-red-600" />}
                  {recommendation.type === 'see-doctor' && <User className="h-4 w-4 text-orange-600" />}
                  {recommendation.type === 'self-care' && <Heart className="h-4 w-4 text-green-600" />}
                  {recommendation.type === 'monitor' && <Clock className="h-4 w-4 text-blue-600" />}
                  {recommendation.type === 'lifestyle' && <CheckCircle className="h-4 w-4 text-purple-600" />}
                </div>
                <p className="text-gray-700">{recommendation.message}</p>
              </div>
            ))}
        </div>
      </div>

      {/* Emergency Contacts */}
      {analysis.urgencyLevel === 'emergency' && (
        <div className="bg-red-600 text-white rounded-lg p-4">
          <h3 className="font-bold mb-2">Emergency Contacts</h3>
          <div className="space-y-1 text-sm">
            <p>Emergency Services: 911</p>
            <p>Poison Control: 1-800-222-1222</p>
            <p>Crisis Hotline: 988</p>
          </div>
        </div>
      )}

      {/* Action Button */}
      <div className="flex justify-center pt-4">
        <button
          onClick={onNewAnalysis}
          className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-3 px-6 rounded-lg transition-colors"
        >
          Start New Assessment
        </button>
      </div>
    </div>
  );
};