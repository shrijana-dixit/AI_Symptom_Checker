import React, { useState } from 'react';
import { Search, Plus, X } from 'lucide-react';
import { Symptom, UserSymptom, SeverityLevel, SymptomCategory } from '../types/medical';
import { symptomsDatabase, symptomCategories } from '../data/symptoms';

interface SymptomSelectorProps {
  selectedSymptoms: UserSymptom[];
  onSymptomsChange: (symptoms: UserSymptom[]) => void;
}

export const SymptomSelector: React.FC<SymptomSelectorProps> = ({
  selectedSymptoms,
  onSymptomsChange
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SymptomCategory | 'all'>('all');

  const filteredSymptoms = symptomsDatabase.filter(symptom => {
    const matchesSearch = symptom.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         symptom.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || symptom.category === selectedCategory;
    const notAlreadySelected = !selectedSymptoms.find(s => s.symptom.id === symptom.id);
    
    return matchesSearch && matchesCategory && notAlreadySelected;
  });

  const addSymptom = (symptom: Symptom, severity: SeverityLevel = 'mild') => {
    const newUserSymptom: UserSymptom = {
      symptom,
      severity,
      duration: '1-2 days'
    };
    onSymptomsChange([...selectedSymptoms, newUserSymptom]);
  };

  const removeSymptom = (symptomId: string) => {
    onSymptomsChange(selectedSymptoms.filter(s => s.symptom.id !== symptomId));
  };

  const updateSymptomSeverity = (symptomId: string, severity: SeverityLevel) => {
    onSymptomsChange(
      selectedSymptoms.map(s => 
        s.symptom.id === symptomId ? { ...s, severity } : s
      )
    );
  };

  const updateSymptomDuration = (symptomId: string, duration: string) => {
    onSymptomsChange(
      selectedSymptoms.map(s => 
        s.symptom.id === symptomId ? { ...s, duration } : s
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* Selected Symptoms */}
      {selectedSymptoms.length > 0 && (
        <div className="bg-blue-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Selected Symptoms ({selectedSymptoms.length})</h3>
          <div className="space-y-3">
            {selectedSymptoms.map((userSymptom) => (
              <div key={userSymptom.symptom.id} className="bg-white rounded-lg p-3 shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-gray-900">{userSymptom.symptom.name}</h4>
                      <button
                        onClick={() => removeSymptom(userSymptom.symptom.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{userSymptom.symptom.description}</p>
                  </div>
                </div>
                
                <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Severity</label>
                    <select
                      value={userSymptom.severity}
                      onChange={(e) => updateSymptomSeverity(userSymptom.symptom.id, e.target.value as SeverityLevel)}
                      className="w-full text-sm border border-gray-300 rounded-md px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="mild">Mild</option>
                      <option value="moderate">Moderate</option>
                      <option value="severe">Severe</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Duration</label>
                    <select
                      value={userSymptom.duration}
                      onChange={(e) => updateSymptomDuration(userSymptom.symptom.id, e.target.value)}
                      className="w-full text-sm border border-gray-300 rounded-md px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="Less than 1 day">Less than 1 day</option>
                      <option value="1-2 days">1-2 days</option>
                      <option value="3-7 days">3-7 days</option>
                      <option value="1-2 weeks">1-2 weeks</option>
                      <option value="More than 2 weeks">More than 2 weeks</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search and Filter */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search symptoms..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === 'all'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All Categories
          </button>
          {symptomCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id as SymptomCategory)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Available Symptoms */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-3">Available Symptoms</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredSymptoms.map((symptom) => (
            <div
              key={symptom.id}
              className="bg-white border border-gray-200 rounded-lg p-3 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{symptom.name}</h4>
                  <p className="text-sm text-gray-600 mt-1">{symptom.description}</p>
                  <div className="mt-2">
                    <span className="inline-block px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">
                      {symptomCategories.find(c => c.id === symptom.category)?.name}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => addSymptom(symptom)}
                  className="ml-2 p-1 text-blue-500 hover:text-blue-700 transition-colors"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
        
        {filteredSymptoms.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No symptoms found matching your search criteria.
          </div>
        )}
      </div>
    </div>
  );
};