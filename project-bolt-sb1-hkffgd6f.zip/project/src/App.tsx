import React, { useState } from 'react';
import { Stethoscope, ArrowRight, ArrowLeft, Shield } from 'lucide-react';
import { SymptomSelector } from './components/SymptomSelector';
import { LoadingAnalysis } from './components/LoadingAnalysis';
import { AnalysisResults } from './components/AnalysisResults';
import { UserSymptom, Analysis } from './types/medical';
import { AISymptomAnalyzer } from './services/aiService';

type AppState = 'welcome' | 'symptoms' | 'analyzing' | 'results';

function App() {
  const [currentState, setCurrentState] = useState<AppState>('welcome');
  const [selectedSymptoms, setSelectedSymptoms] = useState<UserSymptom[]>([]);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);

  const aiAnalyzer = new AISymptomAnalyzer();

  const handleStartAssessment = () => {
    setCurrentState('symptoms');
  };

  const handleAnalyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) {
      alert('Please select at least one symptom before continuing.');
      return;
    }

    setCurrentState('analyzing');
    
    try {
      const result = await aiAnalyzer.analyzeSymptoms(selectedSymptoms);
      setAnalysis(result);
      setCurrentState('results');
    } catch (error) {
      console.error('Analysis error:', error);
      alert('Sorry, there was an error analyzing your symptoms. Please try again.');
      setCurrentState('symptoms');
    }
  };

  const handleNewAnalysis = () => {
    setSelectedSymptoms([]);
    setAnalysis(null);
    setCurrentState('welcome');
  };

  const handleBackToSymptoms = () => {
    setCurrentState('symptoms');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="bg-blue-500 p-3 rounded-full">
              <Stethoscope className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">AI Symptom Checker</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Get personalized health insights based on your symptoms using advanced AI technology
          </p>
        </header>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {currentState === 'welcome' && (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Welcome to Your Health Assessment</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Our AI-powered symptom checker helps you understand your symptoms and provides 
                  personalized recommendations. Start by describing what you're experiencing.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Stethoscope className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Describe Symptoms</h3>
                  <p className="text-sm text-gray-600">Select and describe your current symptoms with severity and duration</p>
                </div>
                
                <div className="text-center p-4">
                  <div className="bg-teal-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Shield className="h-8 w-8 text-teal-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">AI Analysis</h3>
                  <p className="text-sm text-gray-600">Advanced AI processes your symptoms against medical databases</p>
                </div>
                
                <div className="text-center p-4">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <ArrowRight className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Get Insights</h3>
                  <p className="text-sm text-gray-600">Receive personalized recommendations and next steps</p>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-8">
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-amber-800 mb-1">Privacy & Security</h4>
                    <p className="text-sm text-amber-700">
                      Your health information is processed securely and is not stored permanently. 
                      This tool is for informational purposes only and should not replace professional medical advice.
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <button
                  onClick={handleStartAssessment}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg transition-colors inline-flex items-center gap-2"
                >
                  Start Health Assessment
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {currentState === 'symptoms' && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Describe Your Symptoms</h2>
                  <p className="text-gray-600">Select symptoms you're experiencing and provide details about severity and duration</p>
                </div>
                <button
                  onClick={() => setCurrentState('welcome')}
                  className="text-gray-500 hover:text-gray-700 transition-colors inline-flex items-center gap-1 text-sm"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </button>
              </div>

              <SymptomSelector
                selectedSymptoms={selectedSymptoms}
                onSymptomsChange={setSelectedSymptoms}
              />

              <div className="mt-8 flex justify-center">
                <button
                  onClick={handleAnalyzeSymptoms}
                  disabled={selectedSymptoms.length === 0}
                  className={`font-semibold py-3 px-8 rounded-lg transition-colors inline-flex items-center gap-2 ${
                    selectedSymptoms.length > 0
                      ? 'bg-blue-500 hover:bg-blue-600 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Analyze Symptoms ({selectedSymptoms.length})
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {currentState === 'analyzing' && <LoadingAnalysis />}

          {currentState === 'results' && analysis && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Your Health Assessment</h2>
                  <p className="text-gray-600">Based on the symptoms you provided</p>
                </div>
                <button
                  onClick={handleBackToSymptoms}
                  className="text-gray-500 hover:text-gray-700 transition-colors inline-flex items-center gap-1 text-sm"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Edit Symptoms
                </button>
              </div>

              <AnalysisResults
                analysis={analysis}
                onNewAnalysis={handleNewAnalysis}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center text-sm text-gray-500">
          <div className="max-w-2xl mx-auto">
            <p className="mb-2">
              This AI symptom checker is designed for informational purposes only and should not be used as a substitute for professional medical advice, diagnosis, or treatment.
            </p>
            <p>
              Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;