import { Symptom } from '../types/medical';

export const symptomsDatabase: Symptom[] = [
  {
    id: 'fever',
    name: 'Fever',
    category: 'general',
    description: 'Body temperature above normal (>100.4°F or 38°C)',
    commonCauses: ['Infection', 'Inflammation', 'Heat exhaustion', 'Medication reaction']
  },
  {
    id: 'headache',
    name: 'Headache',
    category: 'neurological',
    description: 'Pain in the head or neck area',
    commonCauses: ['Tension', 'Migraine', 'Dehydration', 'Stress', 'Sleep deprivation']
  },
  {
    id: 'cough',
    name: 'Cough',
    category: 'respiratory',
    description: 'Sudden expulsion of air from the lungs',
    commonCauses: ['Cold', 'Flu', 'Allergies', 'Asthma', 'Pneumonia']
  },
  {
    id: 'shortness-breath',
    name: 'Shortness of Breath',
    category: 'respiratory',
    description: 'Difficulty breathing or feeling breathless',
    commonCauses: ['Asthma', 'Anxiety', 'Heart conditions', 'Lung infections']
  },
  {
    id: 'chest-pain',
    name: 'Chest Pain',
    category: 'cardiovascular',
    description: 'Pain or discomfort in the chest area',
    commonCauses: ['Heart conditions', 'Muscle strain', 'Anxiety', 'Acid reflux']
  },
  {
    id: 'nausea',
    name: 'Nausea',
    category: 'digestive',
    description: 'Feeling of sickness with urge to vomit',
    commonCauses: ['Food poisoning', 'Pregnancy', 'Motion sickness', 'Medication']
  },
  {
    id: 'fatigue',
    name: 'Fatigue',
    category: 'general',
    description: 'Extreme tiredness or lack of energy',
    commonCauses: ['Sleep deprivation', 'Stress', 'Anemia', 'Thyroid disorders']
  },
  {
    id: 'dizziness',
    name: 'Dizziness',
    category: 'neurological',
    description: 'Feeling lightheaded or unsteady',
    commonCauses: ['Low blood pressure', 'Dehydration', 'Inner ear problems', 'Medication']
  },
  {
    id: 'sore-throat',
    name: 'Sore Throat',
    category: 'respiratory',
    description: 'Pain or irritation in the throat',
    commonCauses: ['Viral infection', 'Bacterial infection', 'Allergies', 'Dry air']
  },
  {
    id: 'muscle-pain',
    name: 'Muscle Pain',
    category: 'musculoskeletal',
    description: 'Aching or soreness in muscles',
    commonCauses: ['Exercise', 'Injury', 'Stress', 'Viral infections']
  },
  {
    id: 'skin-rash',
    name: 'Skin Rash',
    category: 'skin',
    description: 'Red, irritated, or inflamed skin',
    commonCauses: ['Allergies', 'Infections', 'Eczema', 'Contact dermatitis']
  },
  {
    id: 'anxiety',
    name: 'Anxiety',
    category: 'mental-health',
    description: 'Feelings of worry, nervousness, or unease',
    commonCauses: ['Stress', 'Phobias', 'Medical conditions', 'Substance use']
  }
];

export const symptomCategories = [
  { id: 'general', name: 'General', icon: 'User' },
  { id: 'respiratory', name: 'Respiratory', icon: 'Zap' },
  { id: 'digestive', name: 'Digestive', icon: 'Circle' },
  { id: 'neurological', name: 'Neurological', icon: 'Brain' },
  { id: 'cardiovascular', name: 'Heart & Circulation', icon: 'Heart' },
  { id: 'musculoskeletal', name: 'Muscles & Bones', icon: 'Zap' },
  { id: 'skin', name: 'Skin', icon: 'Layers' },
  { id: 'mental-health', name: 'Mental Health', icon: 'Brain' }
] as const;